<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Dashboard</title>
    <?php include 'views/admin/section/css.php'; ?>

</head>
<!--end::Head-->
<!--begin::Body-->

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    <?php include 'views/admin/section/navber.php'; ?>

        <!--begin::App Main-->
        <main class="app-main">
              <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Blank Page</h3>
                </div>
            </div>
            </div>
        </main>
        <!--end::App Main-->
        <!--begin::Footer-->
<?php include 'views/admin/section/footer.php'; ?>
        <!--end::Footer-->
   