<?php
if($request[0]=='profile'){
    require_once 'views/admin/auth/profile.php';
    die();
}


?>